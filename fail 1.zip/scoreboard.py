FONT = ("Courier", 24, "normal")


class Scoreboard:
    pass
