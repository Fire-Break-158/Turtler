import time
from turtle import Screen, Turtle
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10

class CarManager(Turtle):
    def __init__(self, screen):    
        super().__init__()
        print("hello world")
        self = Turtle()
        self.hideturtle()
        multiples_of_25 = [-220, -180, -140, -100, -60, -20, 20, 60, 100, 140, 180, 220, 260]
        left_or_right = [300, -300]
        self.color(random.choice(COLORS))
        self.shape("square")
        self.shapesize(stretch_len=3, stretch_wid=1.5)
        self.penup()
        self.setpos(random.choice(left_or_right),random.choice(multiples_of_25))
        self.showturtle()
        print(self.pos())

    def movel(self):
        new_x = self.xcor() - MOVE_INCREMENT
        self.screen.goto(new_x, self.ycor())

    def mover(self):
        new_x = self.xcor() + MOVE_INCREMENT
        self.screen.goto(new_x, self.ycor())

    def checkdirection(self):
        print("checkdirection")
        if self.xcor() == 300:
            while self.xcor() != -300:
                self.movel()
        elif self.xcor() == -300:
            while self.xcor() != 300:
                self.mover()

        
