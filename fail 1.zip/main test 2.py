import time
from turtle import Screen, Turtle
from player import Player, STARTING_POSITION
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.bgcolor("black")
screen.setup(width=600, height=600)
screen.tracer(0)

# Create a list of CarManager objects
#cars = []
#for i in range(10):
#    car = CarManager()
#    cars.append(car)

carmgr = CarManager()
carmgr.__init__(self)

player = Player()

game_is_on = True
while game_is_on:
    time.sleep(0.01)

    # Iterate over the list of cars and move them
#    for car in cars:
#        if car.xcor() == 300:
#            car.movel()
#        elif car.xcor() == -300:
#            car.mover()

    # Update the screen
    screen.update()