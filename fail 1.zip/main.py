import time
from turtle import Screen, Turtle
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

game_is_on = True

screen = Screen()
screen.bgcolor("black")
screen.setup(width=600, height=600)

player = Player((0, -280), screen)

#car = Turtle()
#car.shape("square")
#car.color("white")
#car.shapesize(stretch_len=3, stretch_wid=1.5)
#car.penup()



#carmanager = CarManager(screen)
#print(carmanager)



while game_is_on:
    time.sleep(0.01)
    player.screen.update()



screen.exitonclick()