from turtle import Turtle, Screen
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10
SPAWN_POS = (300, -300)

screen = Screen()
screen.bgcolor("black")
screen.setup(width=600, height=600)
screen.tracer(0)


class CarManager(Turtle):
    def __init__(self, SPAWN_POS, screen):
        super().__init__()
        self.shape("square")
        self.color(random.choice(COLORS))
        self.shapesize(stretch_len=3, stretch_wid=1.5)
        self.penup()
        #self.setpos(random.choice(SPAWN_POS))

carmanager = CarManager(SPAWN_POS, screen)

screen.exitonclick()
